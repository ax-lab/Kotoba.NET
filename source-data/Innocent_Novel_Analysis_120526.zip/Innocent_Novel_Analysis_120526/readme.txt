Reports from cb's Japanese Text Analysis Tool v2.0.

Notes:
------

For word_freq_report_jparser.txt, the "Always use kanji form of words"
option was unchecked.

The word_freq_report_diffs folder contains the differences between 
word_freq_report_mecab.txt and word_freq_report_jparser.txt. The 
differences were generated with cb's Frequency Report Diff Tool v1.0.